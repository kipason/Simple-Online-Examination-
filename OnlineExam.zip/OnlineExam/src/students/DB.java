package students;
import java.sql.Connection;
import java.sql.DriverManager;
class DB {
    
    
    public static Connection getConnection()
    {
		Connection con = null;
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/examination","DBA","admin@2026");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
}
