/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package students;
import com.mysql.cj.xdevapi.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author dulahtech
 */
public class Test extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Test.class.getName());

    /**
     * Creates new form Question
     */
    public Test() {
        initComponents();
        loadQuestions();
      
    }
   Connection con;
   PreparedStatement ps;
   ResultSet rs;
    int answercheck=0;
    int marks=0;
    String cor=null;
    String answer=null;
    public boolean answerCheck()
    {
         Connection con=DB.getConnection();
        try{
              String answerAnswer="";
              if(r1.isSelected())
              {
                  
                   answerAnswer=r1.getText();
                  
              }
              else if(r2.isSelected())
              {
                  
                   answerAnswer=r2.getText();
                  
              }
               else if(r3.isSelected())
              {
                  
                   answerAnswer=r3.getText();
                  
              }
               else if(r4.isSelected())
              {
                  
                   answerAnswer=r4.getText();
                  
              }
            if(answerAnswer.equals(cor)&& (answer==null || !answer.equals(cor)))
            {
                
                marks=marks+10;
                txtmarks.setText(String.valueOf(marks));
                
                
            }else if(!answerAnswer.equals(cor)&& answer==null)
            {
                //only deduct if mark is greater than zero /hapa mwanafunzi akichagua jibu wrong alafu akabadilisha
                if(marks>0){
                    
                    
                    marks=marks-10;
                    
                }
                 txtmarks.setText(String.valueOf(marks));
                
            }
            //USE TO STORE ANSWER
            if(!answerAnswer.equals("")){
                 
                try{
                    String sql="UPDATE question SET givenanswer=? WHERE question=?";
                    
                    ps=con.prepareStatement(sql);
                    ps.setString(1, answerAnswer);
                    ps.setString(2,jLabel2.getText());
                    ps.execute();
                    
                }catch(Exception ex){
                    
                    
                    ex.printStackTrace();
                }
                return true;
                
                
            }
            //when no button is selected
            
        }catch(Exception ex){
            
            
            ex.printStackTrace();
        }
        return false;
        
        
        
    }
   private void NullAllGivenAnswers()
   {
        Connection con=DB.getConnection();
       try{
           String query="UPDATE question SET givenanswer=?";
           ps=con.prepareStatement(query);
           ps.setString(1, null);
           ps.execute();
           
           
       }catch(Exception ex){
           
           
           ex.printStackTrace();
       }
       
       
       
       
   }
   //kama swali limeshajibiwa 
    private boolean AlreadyAnswered()
    {
        Connection con=DB.getConnection();
        String qNo=jLabel2.getText();
        try{
            String query="SELECT givenanswer FROM question WHERE question=?";
            ps=con.prepareStatement(query);
            ps.setString(1, qNo);
            rs=ps.executeQuery(query);
            return rs.next();
            
        }catch(Exception ex){
            
            
            
            return false;
        }
       
         
    }
        
    
    //load data
    public void loadQuestions()
    {
        
      try{
          Connection con=DB.getConnection();
          PreparedStatement ps=con.prepareStatement("select * from question",
          ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
          rs=ps.executeQuery();//common mistake ResultSet rs=ps.executeQuery()
          //while(rs.next())
          if(rs.next())
          {
              
              showQuestion();
              
             
              
              
          }

          
          
      }catch(Exception ex) 
      {
          
          System.out.println(ex.getMessage());
          
          
      }
        
        
        
    }
    


public void showQuestion()
{
      Connection con=DB.getConnection();
    
    try{
             
              jLabel3.setText(rs.getString(1));
              jLabel2.setText(rs.getString(2));
              r1.setText(rs.getString(3));
              r2.setText(rs.getString(4));
              r3.setText(rs.getString(5));
              r4.setText(rs.getString(6));
              cor=rs.getString(7);
             if(!AlreadyAnswered()){
                  //clear all button when proceed to the next question and it not answerd
                  buttonGroup1.clearSelection(); 
             }
        
    }catch(Exception ex){
        
        
        
        ex.printStackTrace();
    }
    
    
    
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        r1 = new javax.swing.JRadioButton();
        r2 = new javax.swing.JRadioButton();
        r3 = new javax.swing.JRadioButton();
        r4 = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        txtmarks = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Online Test");

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 204));
        jLabel2.setText("Questions");

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        buttonGroup1.add(r1);
        r1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N

        buttonGroup1.add(r2);
        r2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N

        buttonGroup1.add(r3);
        r3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N

        buttonGroup1.add(r4);
        r4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(r4)
                    .addComponent(r3)
                    .addComponent(r2)
                    .addComponent(r1))
                .addContainerGap(548, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(r1)
                .addGap(34, 34, 34)
                .addComponent(r2)
                .addGap(27, 27, 27)
                .addComponent(r3)
                .addGap(28, 28, 28)
                .addComponent(r4)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 204));
        jLabel3.setText("No");

        jButton1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/arrow_forward_ios_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"))); // NOI18N
        jButton1.setText("Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        txtmarks.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        txtmarks.setForeground(new java.awt.Color(0, 0, 204));
        txtmarks.setText("Marks");

        jButton2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/arrow_back_ios_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png"))); // NOI18N
        jButton2.setText("Previous");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 204));
        jLabel4.setText("Total Scored Marks");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(226, 226, 226)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(76, 76, 76)
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtmarks)
                                .addGap(9, 9, 9))
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(228, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtmarks)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(jButton2)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Next button
         
        if(answerCheck())
        {
             Connection con=DB.getConnection();
            
            try{
                
                if(rs.next()){
                    
                 showQuestion();
                     
                    
                }
                
                       else{
                        
                    JOptionPane.showMessageDialog(this,"No more question");
                    rs.last();
                }
                  
                
                
                
            }catch(Exception ex){
                
                
                JOptionPane.showMessageDialog(this,ex);
            }
        }
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Connection con=DB.getConnection();
        try{
            if(rs.previous()){
                
                
                showQuestion();
                
            }else{
                
                
                JOptionPane.showMessageDialog(this,"This is the first question");
                rs.first();
            }
            
        }catch(Exception e){
            
            
            
            JOptionPane.showMessageDialog(this,e);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Metal".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Test().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton r1;
    private javax.swing.JRadioButton r2;
    private javax.swing.JRadioButton r3;
    private javax.swing.JRadioButton r4;
    private javax.swing.JLabel txtmarks;
    // End of variables declaration//GEN-END:variables
}
