package students;
import java.sql.Connection;
import java.sql.PreparedStatement;
class StudentDao {
    
    public static int save(String stname,int phone,String address,int age){
	int status=0;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("insert into student(stname,phone,address,age) values(?,?,?,?)");
		ps.setString(1,stname);
		ps.setInt(2,phone);
		ps.setString(3,address);
		ps.setInt(4,age);
		status=ps.executeUpdate();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

    
    
    
    
}
